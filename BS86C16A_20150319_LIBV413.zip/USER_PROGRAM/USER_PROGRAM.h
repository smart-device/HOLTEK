// Uploaded by http://smart-device.ir

//***************************************
//***** USER PROGRAM INLUDE FILE*********
//***************************************

//=-------------------------------
//=INCLUDE LIBRARY               -
//=EXTERNAL REFERENCE FILE       -
//=-------------------------------
#include "..\TKS_GLOBE_VARIES.h"
#include "..\BS86C16A_LIBV413\BS86C16A_LIBV413.cex"















