
//*****************************************
//***** TKS CLOBE VARIES DEFINE FOR C CODE*
//*****************************************
#define     _V413_
#define     _CCV3_
//;-SELECT IC BODY & INCLUDE REFERENCE FILE
#define     _BS86C16A_
#include    "BS86C16A-3.H"   

                                 
                            
